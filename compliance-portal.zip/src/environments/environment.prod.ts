export const environment = {
  production: true,
  apiUrl: 'http://20.118.244.149:5000' 
};
