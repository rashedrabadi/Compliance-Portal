export const environment = {
  production: false,
  apiUrl: 'http://20.118.244.149:5000'
};
