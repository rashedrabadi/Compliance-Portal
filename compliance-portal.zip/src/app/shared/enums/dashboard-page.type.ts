export enum DashboardPageType {
  Home = 1,
  UploadNewFile = 2,
  PendingApprovals = 3,
  ApprovedRequests = 4,
  RecentUploads = 5,
  UploadProgress = 6,
  FeedbackReport = 7,
}
